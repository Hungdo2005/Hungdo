#include<stdio.h>
int  main(){
int d, m, y, maxd;  
 printf("Input dd mm yyyy: ");
 scanf("%d %d %d", &d, &m, &y);
     if(m > 12 || m < 1){
     printf("Invalid date");
	 }
 switch(m){
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
		maxd = 31;
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		maxd = 30;	
		break;
	case 2: if( y % 4){
		maxd = 29;
}
	else maxd = 28;
	default: printf("Invalid Date");
} 
if(d <= maxd && d>0){
	printf("Valid Date");
} else{
	printf("Invalid Date");
}
}
